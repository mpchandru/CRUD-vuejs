<template>
  <div>
    <v-toolbar flat color="white">
      <v-toolbar-title>Employees Details</v-toolbar-title>
      <v-divider
        class="mx-2"
        inset
        vertical
      ></v-divider>
      <v-spacer></v-spacer>
	  
	  <!-- dialog start -->
      <v-dialog v-model="dialog">
        <template v-slot:activator="{ on }">
          <v-btn color="primary" dark class="mb-2" v-on="on">New Item</v-btn>
        </template>
        <v-card>
          <v-card-title>
            <span class="headline">{{ formTitle }}</span>
          </v-card-title>
		  
		  
		  <form @submit.prevent="validateBeforeSubmit">
          <v-card-text>
		  <v-container grid-list-md>
		  
              <v-layout wrap>
                <v-flex xs12 sm6 md4>
                  <v-text-field name="name" v-model="editedItem.name" v-validate="'required|alpha'" label="Emp Name"></v-text-field>
				   <span v-show="errors.has('name')" class="help is-danger">{{ errors.first('name') }}</span>
	            </v-flex>
				
                <v-flex xs12 sm6 md4>
                  <v-text-field name="age" v-model="editedItem.age" v-validate="'required|digits:2'" label="Age"></v-text-field>
				  <span v-show="errors.has('age')" class="help is-danger">{{ errors.first('age') }}</span>
                </v-flex>
				
                <v-flex xs12 sm6 md4>
                  <v-text-field name="mobile" v-model="editedItem.mobile" v-validate="'required|digits:10'" label="Mobile No"></v-text-field>
				  <span v-show="errors.has('mobile')" class="help is-danger">{{ errors.first('mobile') }}</span>
                </v-flex>
				
                <v-flex xs12 sm6 md4>
                  <v-text-field name="email" v-model="editedItem.email" v-validate="'required|email'" label="Email Id" ></v-text-field>
				  <span v-show="errors.has('email')" class="help is-danger">{{ errors.first('email') }}</span>
                </v-flex>
				
                <v-flex xs12 sm6 md4>
                  <v-text-field name="empid" v-model="editedItem.empid" v-validate="'required|digits:6'" label="Emp Id"></v-text-field>
				  <span v-show="errors.has('empid')" class="help is-danger">{{ errors.first('empid') }}</span>
                </v-flex>
				
				
              </v-layout>
			  
            </v-container>
			</v-card-text>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn class="blue" flat @click="close">Cancel</v-btn>
            <v-btn class="green" flat @click="save" type="submit">Save</v-btn>
          </v-card-actions>
		  </form>
        </v-card>
      </v-dialog>
	  
	  <!-- dialog end -->
	  
    </v-toolbar>
	
	
	
    <v-data-table
      :headers="headers"
      :items="desserts"
      class="elevation-1"
    >
      <template v-slot:items="props">
        <td>{{ props.item.name }}</td>
        <td class="text-xs-right">{{ props.item.age }}</td>
        <td class="text-xs-right">{{ props.item.mobile }}</td>
        <td class="text-xs-right">{{ props.item.email }}</td>
        <td class="text-xs-right">{{ props.item.empid }}</td>
        <td class="justify-center layout px-0">
          <v-icon
            small
            class="mr-2"
            @click="editItem(props.item)"
          >
            edit
          </v-icon>
          <v-icon
            small
            @click="deleteItem(props.item)"
          >
            delete
          </v-icon>
        </td>
      </template>
	  
	  
      <template v-slot:no-data>
        <v-btn color="primary" @click="initialize">Reset</v-btn>
      </template>
	  
	  
    </v-data-table>
  </div>
</template>




<script>
export default {
  name: 'HelloWorld',
  data: () => ({
	  
	  
      dialog: false,
      headers: [
        {
          text: 'Emp Name',
          align: 'left',
          sortable: false,
          value: 'name'
        },
        { text: 'Age', value: 'age' },
        { text: 'Mobile No', value: 'mobile' },
        { text: 'Email Id', value: 'email' },
        { text: 'Emp Id', value: 'empid' },
        { text: 'Actions', value: 'name', sortable: false }
      ],
      desserts: [],
      editedIndex: -1,
      editedItem: {
        name: '',
        age: '',
        mobile: '',
        email: '',
        empid: ''
      },
      defaultItem: {
        name: '',
        age: 0,
        mobile: 0,
        email: 0,
        empid: 0
      }
    }),

    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'New Item' : 'Edit Item'
      }
    },

    watch: {
      dialog (val) {
        val || this.close()
      }
    },

    created () {
      this.initialize()
    },

    methods: {
	
      initialize () {
        this.desserts = [
          {
            name: 'Chandru',
            age: 25,
            mobile: 8122687619,
            email: 'chandru@gmail.com',
            empid: 112575
          },
          {
            name: 'Senthil',
            age: 23,
            mobile: 8122687620,
            email: 'senthil@gmail.com',
            empid: 112674
          },
          {
            name: 'Mani',
            age: 26,
            mobile: 8122687621,
            email: 'mani@gmail.com',
            empid: 112441
          },
          {
            name: 'Muniraj',
            age: 30,
            mobile: 8122687622,
            email: 'muniraj@gmail.com',
            empid: 118524
          },
          {
            name: 'White',
            age: 35,
            mobile: 8122687623,
            email: 'white@gmail.com',
            empid: 116514
          },
          {
            name: 'Blacky',
            age: 37,
            mobile: 8122687624,
            email: 'blacky@gmail.com',
            empid: 119696
          },
          {
            name: 'Balu',
            age: 39,
            mobile: 8122687625,
            email: 'balu@gmail.com',
            empid: 115454
          },
          {
            name: 'Rajesh',
            age: 40,
            mobile: 8122687626,
            email: 'rajesh@gmail.com',
            empid: 117535
          },
          {
            name: 'Devid',
            age: 45,
            mobile: 8122687627,
            email: 'devid@gmail.com',
            empid: 119811
          },
          {
            name: 'Arun',
            age: 18,
            mobile: 8122687629,
            email: 'arun@gmail.com',
            empid: 113224
          }
        ]
      },

      editItem (item) {
        this.editedIndex = this.desserts.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.dialog = true
      },

      deleteItem (item) {
        const index = this.desserts.indexOf(item)
        confirm('Are you sure you want to delete this item?') && this.desserts.splice(index, 1)
      },

      close () {
        this.dialog = false
        setTimeout(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        }, 300)
      },

      save () {
        if (this.editedIndex > -1) {
          Object.assign(this.desserts[this.editedIndex], this.editedItem)
        } else {
          this.desserts.push(this.editedItem)
        }
        
      },
	  
	  validateBeforeSubmit() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          // eslint-disable-next-line
          alert('Update Successfully..');
		  this.close();
          return;
        }

        
      });
    }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
table tbody tr td {
text-align: left !important;
}
.is-danger {
color: red
}
.flex {
text-align: left;
}
.green {
background: green;
}
.v-btn__content {
color: #fff;
}
.blue {
background: blue;
color: #fff;
}
</style>
